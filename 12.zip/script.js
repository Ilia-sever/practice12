function f1 () 
{
	$("html").click(function () {
		$("#iii").show("explode");
		
	})
	let str;
	$("article div a").click(function () {
		str="#"+$(this).attr('id')+"p"
		$(str).show("drop","right");
	})
	
}